# 感熱式プリンタ

<!---
  original document: 0.8.147:docs/feature_thermal_printer.md
  git diff 0.8.147 HEAD -- docs/feature_thermal_printer.md | cat
-->

<!-- FIXME: Describe thermal printers support here. -->

## 感熱式プリンタのキーコード

| キー | 説明 |
|-----------|----------------------------------------|
| `PRINT_ON` | ユーザが入力した全ての印刷を開始 |
| `PRINT_OFF` | ユーザが入力した全ての印刷を停止 |
