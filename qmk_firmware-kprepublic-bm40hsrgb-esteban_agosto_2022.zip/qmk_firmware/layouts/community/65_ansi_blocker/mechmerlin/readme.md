# MechMerlin's 65_ansi_blocker layout

This is the 65% layout used by u/merlin36, host of the [MechMerlin](www.youtube.com/mechmerlin) 
YouTube channel.

It is used on his   
* [RGB Doro67](https://github.com/qmk/qmk_firmware/tree/master/keyboards/doro67/rgb)
* [KBD67 mkii](https://github.com/qmk/qmk_firmware/tree/master/keyboards/kbdfans/kbd67/mkiirgb/v1)
* [Iron 165](https://github.com/qmk/qmk_firmware/tree/master/keyboards/cannonkeys/iron165)

### Build
To build the firmware file associated with this keymap, simply run `make your_keyboard:mechmerlin`.