# brandonschlack's 65_ansi_blocker layout

This is my preferred 65% layout.

It is used on:

* [Massdrop ALT](https://github.com/qmk/qmk_firmware/tree/master/keyboards/massdrop/alt)     
* [KBD67 MKII](https://github.com/qmk/qmk_firmware/tree/master/keyboards/kbdfans/kbd67/mkiirgb)  

## [Base Layer](http://www.keyboard-layout-editor.com/#/gists/a820c8629394f8f4c3943e6ee518d9a8)
![Base Layer](https://i.imgur.com/gPxDZl7.jpg)

## [Function Layer](http://www.keyboard-layout-editor.com/#/gists/8ca73a6d3bec8ce736f5db60edf31dcf)
![Function Layer](https://i.imgur.com/gNKHgWa.jpg)

